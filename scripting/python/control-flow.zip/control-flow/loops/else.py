for x in range(6):
  print(x)
else:
  print("Finally finished!") 